import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Henry Countries</h1>
    </div>
  );
}

export default App;
